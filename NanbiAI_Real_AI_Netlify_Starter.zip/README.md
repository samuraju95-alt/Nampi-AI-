# Nanba AI web app starter

This is a simple installable-web-app prototype for Android phones.

## Included
- Tamil speech recognition using the browser Web Speech API (if supported)
- Speech output using Android/browser text-to-speech voices
- Tap-to-talk interface, friend name setting, repeat reply, clear chat
- PWA manifest and basic service worker

## Important
- This starter uses simple sample responses, NOT a full generative AI.
- Speech recognition support varies by browser/device and may need internet.
- Female voice depends on voices installed on the phone. Choose a suitable voice in the Voice list if available.
- It does not listen in the background or work as a wake-word assistant while closed.
- The microphone transcript may be processed by your browser's speech recognition provider.
- No chat history is uploaded/saved by this starter.

## Phone-only deployment
To install as a home-screen app, the files must be hosted on an HTTPS website:
1. Extract the ZIP on your phone using a file manager.
2. Upload the three files (`index.html`, `manifest.json`, `sw.js`) to a static hosting service that supports HTTPS.
3. Open the resulting HTTPS website in Chrome.
4. Chrome menu (⋮) → **Add to Home screen** or **Install app**.
Exact menu wording depends on your Android/Chrome version.

Hosting dashboards change over time; if a service asks for Git or a build step, it may be easier to use a static hosting service that supports direct upload.

## To add a real AI brain later
A real AI requires a model provider or hosted AI service. Do not paste a secret API key into `index.html`, because anyone can inspect it. Use a secure backend/proxy and check free-tier limits before enabling it.


## Improved voice build
- Start listening button toggles continuous listening; use Stop listening to stop.
- It tries to restart microphone listening after Nanbi speaks.
- Voice picker lists installed Tamil voices first; speech is slightly slower and higher-pitched.
- Browser speech recognition may still stop or require network/mic permission. This is still a sample-reply prototype, not a connected full AI model.
